Results of experiments. Times were measured on a c5.24xlarge AWS EC2 instance.

The name of each text file consists of the test graph (`orkut`, `brain`,
`webbase`, `friendster`, `blood_vessel`, `cochlea`) and the tested algorithm
(`gbbs` being the GBBS parallel index-based SCAN on 96 threads, `gbbs-serial` being the GBBS
parallel index-based SCAN on one thread, `gs` being GS\*-Index, and `pp` being
ppSCAN).
